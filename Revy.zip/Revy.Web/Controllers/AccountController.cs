﻿namespace Revy.Web.Controllers
{
    using Microsoft.AspNetCore.Identity;
    using Models.BindingModels;
    using Services.Contracts;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using SignInResult = Microsoft.AspNetCore.Identity.SignInResult;

    public class AccountController : Controller
    {
        private readonly IAccountService accountService;

        public AccountController(IAccountService accountService)
        {
            this.accountService = accountService;
        }

        public IActionResult Register()
        {
            if (this.User.Identity.IsAuthenticated)
            {
                return this.Redirect("/");
            }

            return this.View();
        }

        public IActionResult Login()
        {
            if (this.User.Identity.IsAuthenticated)
            {
                return this.Redirect("/");
            }

            return this.View();
        }


        [HttpPost]
        public async Task<IActionResult> Register(RegisterBindingModel model)
        {
            if (!this.ModelState.IsValid)
            {
                return this.View();
            }

            IdentityResult result = await this.accountService.Register(model.Username, model.Email, model.Password);

            if (!result.Succeeded)
            {
                this.ViewBag.Error = "Username or Email already taken";
                return this.View();
            }

            return this.Redirect("/");
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginBindingModel model)
        {
            if (!this.ModelState.IsValid)
            {
                return this.View();
            }

            SignInResult result = await this.accountService.Login(model.Username, model.Password);

            if (!result.Succeeded)
            {
                this.ViewBag.Error = "Invalid Username or Password";
                return this.View();
            }

            return this.Redirect("/");
        }

        public async Task<IActionResult> Logout()
        {
            await this.accountService.Logout();

            return this.Redirect("/");
        }
    }
}