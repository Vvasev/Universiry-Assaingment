﻿namespace Revy.Web
{
    using Data;
    using Entities;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Routing;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Revy.Services;
    using Revy.Services.Contracts;

    public class Startup
    {

        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
        }

        public IConfiguration Configuration { get; set; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.Configure<RouteOptions>(x => x.LowercaseUrls = true);

            services.AddDbContext<RevyContext>(x =>
            {
                x.UseSqlServer(this.Configuration.GetConnectionString("Default"));
            });

            services.AddIdentity<User, IdentityRole>(options =>
                {
                    options.User = new UserOptions
                    {
                        RequireUniqueEmail = true
                    };

                    options.Password = new PasswordOptions
                    {
                        //TODO Fix with proper values

                        RequireDigit = false,
                        RequiredLength = 3,
                        RequireLowercase = false,
                        RequireUppercase = false,
                        RequiredUniqueChars = 0,
                        RequireNonAlphanumeric = false
                    };
                })
                .AddEntityFrameworkStores<RevyContext>()
                .AddDefaultTokenProviders();

            services.AddScoped<IAccountService,AccountService>();
            
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            app.UseCookiePolicy();
            app.UseDeveloperExceptionPage();
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseAuthentication();
            app.UseMvcWithDefaultRoute();
        }
    }
}