﻿namespace Revy.Web.TagHelpers
{
    using Microsoft.AspNetCore.Razor.TagHelpers;
    using System.Text;

    public class ErrorTagHelper : TagHelper
    {
        public string Message { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            if (string.IsNullOrWhiteSpace(this.Message))
            {
                return;
            }

            output.TagName = "span";

            StringBuilder sb = new StringBuilder();

            sb.Append($@"<h4 class=""alert alert-danger text-center"">{this.Message}</h5>");

            output.Content.SetHtmlContent($"{sb}");
        }
    }
}