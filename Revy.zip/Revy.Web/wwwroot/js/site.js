﻿$(() => {

    let header = $(".business-header");
    let pictures =
        [
            '/images/hero1.jpg',
            '/images/hero2.jpg',
            '/images/hero3.jpg'
        ];
    let index = 0;
    function nextBackground() {
        header.css({
            "background": `url(${pictures[index % pictures.length]}) center center no-repeat scroll`,
            "transitionDuration": "3s"
        });
        index++;
        setTimeout(nextBackground, 7000);
    }
    setTimeout(nextBackground, 0);
    header.css("background", pictures[0]);
});
