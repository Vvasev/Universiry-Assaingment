﻿using System.ComponentModel.DataAnnotations;

namespace Revy.Web.Models.BindingModels
{
    using Infrastructire.Constants;

    public class LoginBindingModel
    {
        [Required(ErrorMessage = RevyConstants.RequiredAttributeMessage)]
        public string Username { get; set; }
        
        [Required(ErrorMessage = RevyConstants.RequiredAttributeMessage)]
        public string Password { get; set; }
    }
}