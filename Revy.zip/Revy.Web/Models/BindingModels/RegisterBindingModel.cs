﻿namespace Revy.Web.Models.BindingModels
{
    using Revy.Infrastructire.Constants;
    using System.ComponentModel.DataAnnotations;
    using Infrastructire.Attributes;

    public class RegisterBindingModel
    {
        [Required(ErrorMessage = RevyConstants.RequiredAttributeMessage)]
        [StringLength(12,MinimumLength = 3,ErrorMessage = RevyConstants.LengthAttributeMessage)]
        public string Username { get; set; }

        
        [Required(ErrorMessage = RevyConstants.RequiredAttributeMessage)]
        [StringLength(16,MinimumLength = 6,ErrorMessage = RevyConstants.LengthAttributeMessage)]
        [CustomEmail(ErrorMessage = RevyConstants.EmailAttributeMessage)]
        public string Email { get; set; }

        [Required(ErrorMessage = RevyConstants.RequiredAttributeMessage)]
        [StringLength(32,MinimumLength = 6,ErrorMessage = RevyConstants.LengthAttributeMessage)]
        public string Password { get; set; }
        
        [Compare(nameof(Password),ErrorMessage = RevyConstants.ConfirmPasswordAttributeMessage)]
        public string ConfirmPassword { get; set; }
    }
}
