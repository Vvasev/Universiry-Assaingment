namespace Revy.Data.EntityConfiguration
{
    using Entities;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class VideoEntityConfiguration : IEntityTypeConfiguration<Video>
    {
        public void Configure(EntityTypeBuilder<Video> builder)
        {
            builder.HasKey(x => x.Id);

            builder.Property(x => x.YouTubeId)
                .IsRequired();

            builder.Property(x => x.PlainYoutubeId)
                .IsRequired();


            builder.HasOne(x => x.Review)
                .WithOne(x => x.Video)
                .HasForeignKey<Video>(x => x.ReviewId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}