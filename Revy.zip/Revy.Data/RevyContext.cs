﻿namespace Revy.Data
{
    using Entities;
    using EntityConfiguration;
    using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore;

    public class RevyContext : IdentityDbContext<User>
    {
        public RevyContext()
        {
        }

        public RevyContext(DbContextOptions options) : base(options)
        {   
        }

        public DbSet<Review> Reviews { get; set; }

        public DbSet<Video> Videos { get; set; }


        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfiguration(new UserEntityConfiguration());
            builder.ApplyConfiguration(new VideoEntityConfiguration());
            builder.ApplyConfiguration(new ReviewEntityConfiguration());
            
            base.OnModelCreating(builder);
        }
    }
}