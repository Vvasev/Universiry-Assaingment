﻿namespace Revy.Infrastructire.Constants
{
    public static class RevyConstants
    {
        public const string RequiredAttributeMessage = "{0} is required";

        public const string LengthAttributeMessage = "{0} must be more than {2} and less then {1} symbols long";

        public const string EmailAttributeMessage = "Invalid {0} address";

        public const string ConfirmPasswordAttributeMessage = "Passwords does not match";
    }
}
