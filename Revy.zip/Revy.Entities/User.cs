﻿namespace Revy.Entities
{
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Identity;

    public class User : IdentityUser
    {
        
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Country { get; set; }

        public ICollection<Review> Reviews { get; set; } = new List<Review>();
    }
}