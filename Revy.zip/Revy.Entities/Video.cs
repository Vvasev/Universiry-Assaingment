namespace Revy.Entities
{
    using System;

    public class Video
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string YouTubeId { get; set; }

        public string PlainYoutubeId { get; set; }

        public string ReviewId { get; set; }

        public Review Review { get; set; }
    }
}