﻿namespace Revy.Services
{
    using System.Threading.Tasks;
    using Contracts;
    using Entities;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.EntityFrameworkCore;

    public class AccountService : IAccountService
    {
        private readonly UserManager<User> userManager;
        private readonly SignInManager<User> signInManager;

        public AccountService(UserManager<User> userManager, SignInManager<User> signInManager)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
        }

        public async Task<SignInResult> Login(string username, string password)
        {
            User user = await this.userManager.Users.SingleOrDefaultAsync(x => x.UserName == username);
            if (user != null)
            {
                return await this.signInManager.PasswordSignInAsync(user, password, false, false);

            }
            return SignInResult.Failed;
        }

        public async Task Logout()
        {
            await this.signInManager.SignOutAsync();
        }

        public async Task<IdentityResult> Register(string username, string email, string password)
        {
            User user = new User()
            {
                UserName = username,
                Email = email
            };
            return await this.userManager.CreateAsync(user, password);
        }
    }
}