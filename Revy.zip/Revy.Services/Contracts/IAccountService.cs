﻿using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;

namespace Revy.Services.Contracts
{
    public interface IAccountService
    {
        Task<IdentityResult> Register(string username, string email, string password);

        Task<SignInResult> Login(string username, string password);

        Task Logout();
    }
}
